// App.js

import React from "react";

// const CLIENT_ID = "44a61fa4-3712-40ce-aad7-f1f9b5bd8667";
// const REDIRECT_URI = "http://127.0.0.1:3000"; // Your redirect URI

function Login() {
  const handleLogin = async () => {
    try {
      const loginUrl = `http://localhost:3001/login`;
      // Redirect to Upstox login page
      window.location.href = loginUrl;
    } catch (error) {
      alert("Failed to initiate login");
    }
  };

  return (
    <div>
      <h1>Welcome to Stock Market Website</h1>
      <button onClick={handleLogin}>Login with Upstox</button>
    </div>
  );
}

export default Login;
