const express = require("express");
const axios = require("axios");
const querystring = require("querystring");

const app = express();
const PORT = 3001;

const CLIENT_ID = "44a61fa4-3712-40ce-aad7-f1f9b5bd8667";
const CLIENT_SECRET = "xsl5zldfe5"; // Your client secret
const REDIRECT_URI = "http://127.0.0.1:3000"; // Your redirect URI

app.use(express.json());

app.get("/", (req, res) => {
  res.send("Server is running");
});

// Endpoint to initiate Upstox login and handle callback
app.get("/login", async (req, res) => {
  const { code } = req.query;

  if (code) {
    try {
      // Exchange code for access token
      const tokenParams = {
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        code: code,
        redirect_uri: REDIRECT_URI,
        grant_type: "210297",
      };

      const tokenResponse = await axios.post(
        "https://api.upstox.com/v2/login/oauth2/token",
        querystring.stringify(tokenParams),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Accept: "application/json",
          },
        }
      );

      // Log and return access token
      const accessToken = tokenResponse.data.access_token;
      console.log("Access Token:", accessToken);
      res.json({ access_token: accessToken });
    } catch (error) {
      console.error("Access Token Error:", error.message);
      res.status(400).json({ error: "Failed to get access token" });
    }
  } else {
    // If no code, initiate Upstox login
    const loginUrl = `https://api.upstox.com/v2/login/authorization/dialog?client_id=${CLIENT_ID}&redirect_uri=${REDIRECT_URI}&response_type=code`;

    // Redirect to Upstox login page
    res.redirect(loginUrl);
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
